"""
hmmlearn
========

``hmmlearn`` is a set of algorithms for learning and inference of
Hiden Markov Models.
"""

__version__ = "0.2.1"
